import paramiko,time,datetime,threading
from pymongo import MongoClient

from email import encoders
from email.header import Header
from email.mime.text import MIMEText
from email.utils import parseaddr, formataddr
import smtplib

my_conn = MongoClient('192.168.1.31',28017)
my_db = my_conn.proxyapi


def comm(bash_ip,ssh_ip,ssh_port,username,password):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ssh_ip, ssh_port, username, password)
        stdin, stdout, stderr = ssh.exec_command("ps -aux |grep adsl.py |grep -v 'grep'|wc -l")
        n = stdout.read().decode().split('\n')[0]
        with open("outtime.txt","a") as f:
            f.write(bash_ip+" : "+n+"\n")
        if n == "0":
            stdin1, stdout1, stderr1 = ssh.exec_command('nohup python /root/adsl.py &')
        if n == "1":
            stdin, stdout, stderr = ssh.exec_command('adsl-stop')
            stdin1, stdout1, stderr1 = ssh.exec_command('poff -a')
        ssh.close()
    except:
        with open("outtime.txt","a") as f:
            f.write(bash_ip+" : timeout\n")
def _format_addr(s):
    name, addr = parseaddr(s)
    return formataddr((Header(name, 'utf-8').encode(), addr))

def send_mail(send_str):
    from_addr = "13368085582@163.com"
    password = "xyz1022"
    to_addr = "360203592@qq.com"
    smtp_server = "smtp.163.com"

    msg = MIMEText(send_str, 'plain', 'utf-8')
    msg['From'] = _format_addr('ProxyAPI <%s>' % from_addr)
    msg['To'] = _format_addr('管理员 <%s>' % to_addr)
    msg['Subject'] = Header('ProxyAPI故障提示', 'utf-8').encode()

    server = smtplib.SMTP(smtp_server, 25)
    server.set_debuglevel(1)
    server.login(from_addr, password)
    server.sendmail(from_addr, [to_addr], msg.as_string())
    server.quit()
send_str_l = []
strip_n = 0
while True:
    host_l = []
    send_str = ""
    hosts = my_db.proxyapi.find()
    f_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    with open("outtime.txt","a") as f:
        f.write("==========="+f_time+"==========\n")
    for i in hosts:
        # print(i)
        bash_ip = i["bash_ip"]
        t_ime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        t_ime_t = time.mktime(datetime.datetime.strptime(t_ime, "%Y-%m-%d %H:%M:%S").timetuple())
        r_time = i['time']
        r_time_t = time.mktime(datetime.datetime.strptime(r_time, "%Y-%m-%d %H:%M:%S").timetuple())
        if int(t_ime_t) - int(r_time_t) > 300:
            my_coll = list(my_db.ssh.find({"bash_ip": bash_ip}))
            try:
                ssh_ip = my_coll[0]['ssh_ip']
                ssh_port = my_coll[0]['ssh_port']
                username = my_coll[0]['username']
                password = my_coll[0]['password']
                if send_str == "":
                    send_str = bash_ip
                else:
                    send_str = send_str+","+bash_ip
                host_l.append(bash_ip)
                # print(bash_ip,ssh_ip,ssh_port,username,password)
                t1 = threading.Thread(target=comm, args=(bash_ip,ssh_ip,ssh_port,username,password))
                t1.start()
            except:
                with open("outtime.txt", "a") as f:
                    f.write(bash_ip+" 没有账号好密码\n")
    send_str = f_time +" 故障主机有"+str(len(host_l))+"台 ： "+send_str
    with open("outtime.txt", "a") as f:
        f.write("故障主机有"+str(len(host_l))+"台\n")
    if strip_n in [0, 20, 40, 60, 80]:
        send_str_l.append(send_str)
    if strip_n == 80:
        while len(send_str_l) > 5:
            del send_str_l[0]
        send_mail("\n".join(send_str_l))
        strip_n = 0
    strip_n +=1
    time.sleep(300)
