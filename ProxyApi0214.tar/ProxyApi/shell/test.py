from pymongo import MongoClient
import bson
mongo_conn = MongoClient('192.168.1.46',27017)
mongo_db = mongo_conn.proxyapi
groups = mongo_db.ssh.aggregate([
    {'$group': {"_id": "$addr"}},
    {'$sort': {"_id": 1}},
])
group_list = []
for i in groups:
    group_list.append(i['_id'])

print(len(group_list))


























# a =mongo_db.ssh.find()
#
# for i in a:
#     bash_ip = i['bash_ip']
#     addr = list(mongo_db.proxyapi.find({'bash_ip':bash_ip}))[0]['addr']
#     print(addr)
#     mongo_db.ssh.update({'bash_ip':bash_ip},{'$set':{'addr':addr}})
