from django.apps import AppConfig


class ShellConfig(AppConfig):
    name = 'shell'
