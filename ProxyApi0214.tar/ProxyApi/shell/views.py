from django.shortcuts import render,HttpResponse
from auth.views import auth
import paramiko,os
from pymongo import MongoClient
import json
import Api.views as Av
# Create your views here.
mongo_conn = MongoClient('192.168.1.31',28017)
mongo_db = mongo_conn.proxyapi

def getaddrs():
    addrs = mongo_db.ssh.aggregate([
        {'$group': {"_id": "$addr"}},
        {'$sort': {"_id": -1}},
    ])
    addr_list = []
    for i in addrs:
        addr_list.append(i['_id'])
    return addr_list
@auth
def gethosts(request):
    addr = request.GET.get('addr')
    ips = mongo_db.ssh.aggregate([
        { '$match':{'addr':addr}},
        {'$sort': {"bash_ip": 1}},
    ])
    iphtml_list = []
    for i in ips:
        html = "<option value='%s'>%s</option>"%(i['bash_ip'],i['bash_ip'])
        iphtml_list.append(html)
    return HttpResponse(iphtml_list)
def getip(request):
    bash_ip = request.GET.get('bash_ip')
    ip = list(mongo_db.ssh.find({'bash_ip': bash_ip}))[0]['ssh_ip']
    port = list(mongo_db.ssh.find({'bash_ip':bash_ip}))[0]['ssh_port']

    return HttpResponse(ip+':'+port)
@auth
def addhosts(request):
    bash_ip = request.GET.get('bash_ip')
    ssh_ip = request.GET.get('ssh_ip')
    ssh_port = request.GET.get('ssh_port')
    username = request.GET.get('username')
    password = request.GET.get('password')
    addr = request.GET.get('addr')
    msg = '添加成功'
    try:
        rs = mongo_db.ssh.insert({'bash_ip': bash_ip, 'ssh_ip': ssh_ip,'ssh_port': ssh_port,'username': username, 'password': password, 'addr': addr})
        print(bash_ip,ssh_ip,ssh_port,username,password,addr)
        if not rs:
            msg = '添加失败'
    except:
        msg = '添加失败'
    return HttpResponse(msg)
@auth
def updatehosts(request):
    bash_ip = request.GET.get('bash_ip')
    ssh_ip = request.GET.get('ssh_ip')
    ssh_port = request.GET.get('ssh_port')
    username = request.GET.get('username')
    password = request.GET.get('password')
    addr = request.GET.get('addr')
    msg = '更新成功'
    try:
        rs = mongo_db.ssh.update({"bash_ip":bash_ip},{"$set":{'bash_ip': bash_ip, 'ssh_ip': ssh_ip,'ssh_port': ssh_port,'username': username, 'password': password, 'addr': addr}})
        rs1 = mongo_db.proxyapi.update({"bash_ip":bash_ip},{"$set":{'bash_ip': bash_ip, 'addr': addr}})
        Av.updataip(bash_ip,addr)
        if rs['n'] == 0:
            msg = '更新失败'
    except:
        print('err')
        msg = '更新失败'
    return HttpResponse(msg)
@auth
def dellhosts(request):
    bash_ip = request.GET.get('bash_ip')
    msg = '删除成功'
    try:
        rs = mongo_db.ssh.remove({"bash_ip":bash_ip})
        rs1 = mongo_db.proxyapi.remove({"bash_ip":bash_ip})
        Av.dellip(bash_ip)
        if rs['n'] == 0:
            msg = '删除失败'
    except:
        msg = '删除失败'
    return HttpResponse(msg)
dir_dict = {}
@auth
def comm(request):
    addr = request.GET.get('addr')
    bash_ip = request.GET.get('bash_ip')
    comm = request.GET.get('comm')
    if bash_ip == '请选择IP':
        bash_ip = ''
    data = {}
    if not bash_ip:
        ips = mongo_db.ssh.aggregate([
            {'$match': {'addr': addr}},
            {'$sort': {"ssh_ip": 1}},
        ])
    else:
       ips = ips = mongo_db.ssh.find({'bash_ip':bash_ip})
    for i in ips:
        ssh_ip = i['ssh_ip']
        bash_ip = i['bash_ip']
        ssh_port = i['ssh_port']
        username = i['username']
        password = i['password']
        try:
            # 创建SSH对象
            ssh = paramiko.SSHClient()
            # 允许连接不在know_hosts文件中的主机
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            # 连接服务器
            ssh.connect(ssh_ip, ssh_port, username, password)
        except:
            continue
        if bash_ip not in dir_dict.keys():
            dir_dict[bash_ip] = ['/root/']
        comm_split = comm.split()
        if comm_split[0] == 'cd':
            comm_dir = comm_split[1]
            comm_dir_split = comm_dir.split('/')
            if comm_dir.startswith('/'):
                dir = comm_dir
            elif comm_dir=='..' and len(dir_dict[bash_ip])>1:
                dir_dict[bash_ip].pop()
            else:
                if dir_dict[bash_ip][-1].endswith('/'):
                    dir = dir_dict[bash_ip][-1] + comm_dir
                else:
                    dir = dir_dict[bash_ip][-1]+'/'+comm_dir
            dir_dict[bash_ip].append(dir)
            c_omm = 'cd '+dir_dict[bash_ip][-1]+';pwd'
            stdin, stdout, stderr = ssh.exec_command(c_omm)
            stdout_list = stdout.read().decode().split('\n')[0:-1]
            if stdout_list[0] == '/root' and (comm_dir != '/root' and comm_dir != '/root/'):
                dir_dict[bash_ip].pop()
                stdout_list[0]='目录不存在'
            elif stdout_list[0] == '/root' and (comm_dir == '/root' or comm_dir == '/root/'):
                dir_dict[bash_ip] = ['/root/']
            elif  (len(comm_dir_split) == 2 or (len(comm_dir_split) == 3 and comm_dir_split[-1] == '')) and comm_dir.startswith('/'):
                dir_dict[bash_ip] = ['/root/']
                dir_dict[bash_ip].append(dir)
        else:
            c_omm = 'cd '+dir_dict[bash_ip][-1] + ';' + comm
            stdin, stdout, stderr = ssh.exec_command(c_omm)
            stdout_list = stdout.read().decode().split('\n')[0:-1]
        if len(stdout_list) == 0:
            data[bash_ip] = stderr.read().decode().split('\n')[0:-1]
        else:
            data[bash_ip] = stdout_list
        ssh.close()
    data=json.dumps(data)
    return HttpResponse(data)
@auth
def index(request):
    addr_list = getaddrs()
    return render(request, 'shell_index.html',{'addrs':addr_list})
@auth
def hosts(request):
    addr_list = getaddrs()
    addr = request.GET.get('addr')
    if  addr=='请选择分组':
        addr = ''
    if not addr  or  mongo_db.ssh.count({'addr': addr})==0:
        addr = ''
        ips = mongo_db.ssh.aggregate([
            {'$sort': {"bash_ip": 1}},
        ])
    else:
        ips = mongo_db.ssh.aggregate([
            {'$match': {'addr': addr}},
            {'$sort': {"bash_ip": 1}},
        ])
        # print(len(ips))
    # ips_list = []
    # for i in ips:
    #     d = {
    #         'id': i['_id'],
    #         'group': i['addr'],
    #         'bash_ip': i['bash_ip'],
    #         'ssh_ip': i['ssh_ip'],
    #         'port': i['port'],
    #         'uaername': i['username'],
    #     }
    #
    #     ips_list.append(d)
    ips_l = list(ips)
    return render(request,'shell_hosts.html',{'addr':addr,'addrs':addr_list,'ips':ips_l,'count':len(ips_l)})
