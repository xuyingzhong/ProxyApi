from django.test import TestCase

# # Create your tests here.
# import paramiko,os
# pkey = paramiko.RSAKey.from_private_key_file('D:\managesever/\shell/\id_rsa')
# trans = paramiko.Transport(('10.8.8.231', 22))
# trans.connect(username='root', pkey=pkey)
# ssh = paramiko.SSHClient()
# ssh._transport = trans
# stdin, stdout, stderr = ssh.exec_command('ls')
# # print(stdout.read().decode())
# # print(stderr.read().decode())

print(len())