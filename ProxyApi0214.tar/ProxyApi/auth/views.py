from django.shortcuts import render,redirect
# Create your views here.
def login(request):
    if request.method=='GET':
        agent = request.META.get('HTTP_USER_AGENT','')
        print(agent)
        reagent = ''
        if 'Chrome' not in agent:
            reagent ='请使用谷歌浏览器'
        return render(request,'login.html',{'reagent':reagent})
    if request.method=='POST':
        passwd = request.POST.get('passwd')
        if passwd in ['xyz','lhrh']:
            request.session['passwd']=passwd
            return redirect('/shell')
        else:
            return render(request, 'login.html')
def logout(request):
    request.session.clear()
    return redirect('/login')
def auth(func):
    def inner(request,*args,**kwargs):
        v = ""
        try:
            v = request.session['passwd']
        except:
            pass
        if not v:
            return redirect('/login')
        return func(request, *args,**kwargs)
    return inner
@auth
def index(request):
    return render(request,'index.html')
