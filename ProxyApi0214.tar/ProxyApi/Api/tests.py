from pymongo import MongoClient
import paramiko
my_conn = MongoClient('192.168.1.46',27017)
my_db = my_conn.proxyapi


my_conn.proxyapi.ssh.update({"bash_ip" : "云hifo039"},{'$set':{"ssh_ip" : "112.112.193.162","ssh_port" : "20239"}})
