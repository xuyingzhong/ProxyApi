from django.shortcuts import render,HttpResponse
import random,time,datetime,json,threading
from pymongo import MongoClient

my_conn = MongoClient('192.168.1.31',28017)
my_db = my_conn.proxyapi
proxy_ip_dic = {}
for i in my_conn.proxyapi.proxyapi.find():
    proxy_ip_dic[i['bash_ip']] = {'proxy_ip':i['proxy_ip'],'re_ip':i['re_ip'],'addr':i['addr'],'time':i['time'],'timeout':i['timeout']}

def addip(request):
    ip_dic = {}
    allip_dic = {}
    addr = request.GET.get('addr')
    bash_ip = request.GET.get('baship')
    proxy_ip = request.GET.get('proxy_ip')
    try:
        re_ip = request.META['HTTP_X_FORWARDED_FOR']
    except:
        re_ip = request.META['REMOTE_ADDR']
    if proxy_ip == None:
        proxy_ip = re_ip
    if bash_ip == None or addr == None:
        rec =re_ip
    else:
        ip_dic['proxy_ip'] = proxy_ip
        ip_dic['re_ip'] = re_ip
        allip_dic['re_ip'] = re_ip
        ip_dic['addr'] = addr
        d_time = datetime.datetime.now()
        t_ime = d_time.strftime("%Y-%m-%d %H:%M:%S")
        i_time = int(time.mktime(d_time.timetuple()))
        ip_dic['time'] = t_ime
        allip_dic['time'] = t_ime
        ip_dic['timeout'] = 0
        ip_dic['i_time'] = i_time
        allip_dic['i_time'] = i_time
        proxy_ip_dic[bash_ip] = ip_dic
        my_db.proxyapi.update({'bash_ip':bash_ip},{'$set':ip_dic},upsert=True)
        ssh = list(my_db.ssh.find({'bash_ip': bash_ip}))
        if len(ssh)>0 and ssh[0]['addr']==addr:
            pass
        elif len(ssh)>0 and ssh[0]['addr']!=addr:
            my_db.ssh.update({'bash_ip': bash_ip},{'bash_ip': bash_ip, 'ssh_ip': ssh[0]['ssh_ip'],'ssh_port':ssh[0]['ssh_port'],'username':ssh[0]['username'],'password':ssh[0]['password'],'addr': addr})
        else:
            my_db.ssh.update({'bash_ip': bash_ip}, {'bash_ip': bash_ip,'addr': addr}, upsert=True)
        allip_dic['bash_ip'] = bash_ip
        my_db.allproxyapi.insert(allip_dic)
        t1 = threading.Thread(target=timeout, args=(bash_ip,))
        t1.start()
        rec = 'Add ip Success'
    return HttpResponse(rec)

def timeout(bash_ip):
    ips = list(my_db.allproxyapi.aggregate([{'$match': {'bash_ip': bash_ip}}, {'$sort': {'i_time': -1}}, {'$limit': 3}]))
    if ips[0]['re_ip'] == ips[1]['re_ip'] == ips[2]['re_ip']:
        proxy_ip_dic[bash_ip]['timeout'] = 2
        my_db.proxyapi.update({'bash_ip': bash_ip}, {'$set': {'timeout': 2}})
    else:
        time.sleep(240)
        t_ime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        t_ime_t = time.mktime(datetime.datetime.strptime(t_ime, "%Y-%m-%d %H:%M:%S").timetuple())
        r_time = my_conn.proxyapi.proxyapi.find({'bash_ip': bash_ip})[0]['time']
        r_time_t = time.mktime(datetime.datetime.strptime(r_time, "%Y-%m-%d %H:%M:%S").timetuple())
        if int(t_ime_t) - int(r_time_t) > 230:
            proxy_ip_dic[bash_ip]['timeout'] = 1
            my_db.proxyapi.update({'bash_ip': bash_ip}, {'$set': {'timeout': 1}})
def getip(request):
    try:
        re_ip = request.META['HTTP_X_FORWARDED_FOR']
    except:
        re_ip = request.META['REMOTE_ADDR']
    with open('getreip.txt','a') as f:
        f.write(re_ip+'\n')
    bash_ip = request.GET.get('ip')
    addr = request.GET.get('addr')
    tof = request.GET.get('tof')
    try:
        addr_list = addr.split(',')
    except:
        addr_list = []
    if tof == None:
        tof = 't'
    proxy_ip_list = []
    for i in proxy_ip_dic:
        if  proxy_ip_dic[i]['timeout'] == 0:
            proxy_ip_list.append(i)
    rec_str = 'None'
    rec_list_t =[]
    rec_list_f =[]
    if len(proxy_ip_list) == 0:
        pass
    else:
        if bash_ip == None:
            if len(addr_list) == 0:
                i = random.choice(proxy_ip_list)
                rec_str= proxy_ip_dic[i]['proxy_ip']
            else:
                for addr_str in addr_list:
                    for i in proxy_ip_list:
                        if addr_str in proxy_ip_dic[i]['addr']:
                            rec_list_t.append(proxy_ip_dic[i]['proxy_ip'])
                rec_list_f = list(set(proxy_ip_list).difference(set(rec_list_t)))
                try:
                    if tof == 't':
                        rec_str = proxy_ip_dic[random.choice(rec_list_t)]['proxy_ip']
                    else:
                        rec_str = proxy_ip_dic[random.choice(rec_list_f)]['proxy_ip']
                except:
                    pass
        else:
            try:
                if bash_ip in proxy_ip_list:
                    rec_str = proxy_ip_dic[bash_ip]['proxy_ip']
            except:
                pass
    return HttpResponse(rec_str)

def checkip(request):
    addr = request.GET.get('addr')
    rec_dic = {}
    proxy_ip_list = list(proxy_ip_dic)
    proxy_ip_len = len(proxy_ip_list)
    if proxy_ip_len ==0:
        return HttpResponse('[None]')
    else:
        proxy_ip_list.sort()
        for i in proxy_ip_list:
            if addr == None:
                rec_dic[i] = proxy_ip_dic[i]
                # rec_dic[i]['count'] = my_db.allproxyapi.find({'bash_ip': i}).count()
                # rec_dic[i]['g_count'] = len(list(my_db.allproxyapi.aggregate([{'$match': {'bash_ip': i}}, {'$group': {'_id': "$re_ip"}}])))
            else:
                if addr in proxy_ip_dic[i]['addr']:
                    rec_dic[i] = proxy_ip_dic[i]
                    # rec_dic[i]['count'] = my_db.allproxyapi.find({'bash_ip': i}).count()
                    # rec_dic[i]['g_count'] = len(list(my_db.allproxyapi.aggregate([{'$match': {'bash_ip': i}}, {'$group': {'_id': "$re_ip"}}])))
        proxy_ip_len = len(list(rec_dic))
        return render(request,'check.html',{'proxy_ip_len':proxy_ip_len,'rec_dic':rec_dic})

def ipdetail(request):
    bash_ip = request.GET.get('ip')
    re_list = []
    re_list.append(bash_ip + '：')
    count = my_db.allproxyapi.find({'bash_ip':bash_ip}).count()
    re_list.append('一共提供了'+str(count)+'次ip地址')
    g_count = my_db.allproxyapi.aggregate([{'$match':{'bash_ip':bash_ip}},{'$group':{'_id':"$re_ip"}}])
    re_list.append('一共提供了' + str(len(list(g_count))) + '个不重复ip地址')
    ips = my_db.allproxyapi.aggregate([{'$match':{'bash_ip':bash_ip}},{'$sort':{'i_time':-1}},{'$limit':20}])
    re_list.append('最近20次记录：')
    for i in ips:
        re_list.append(i['re_ip']+'    '+i['time'])
    re = json.dumps('\n'.join(re_list))
    return HttpResponse(re)

def dellip(bash_ip):
    del proxy_ip_dic[bash_ip]
def updataip(bash_ip,addr):
    proxy_ip_dic[bash_ip]['addr'] = addr
