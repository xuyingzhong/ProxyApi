# from django.contrib import admin
from django.urls import path,include
from shell import views

urlpatterns = [
    path('',views.index),
    path('hosts',views.hosts),
    path('updatehosts',views.updatehosts),
    path('dellhosts',views.dellhosts),
    path('addhosts',views.addhosts),
    path('getaddrs',views.getaddrs),
    path('getip',views.getip),
    path('gethosts',views.gethosts),
    path('comm',views.comm),
    path('index', views.index),
]
